<template>
<div class>
    <ul class="nav justify-content-end">

  <li class="nav-item">
    <router-link to="/login" style="float:right">Login</router-link>

  </li>

</ul>

   <div>
    <h1 id="main-title" class="text-center">Go Green</h1>
    <b-nav tabs justified>
    <b-nav-item>Link1</b-nav-item>
    <b-nav-item><router-link to="/">Search</router-link></b-nav-item>
    <b-nav-item>Link3</b-nav-item>
    <b-nav-item>Link4</b-nav-item>
  </b-nav>
</div>
</div>
</template>

<script>
// import Vue from 'vue'
export default {
    name:"Header",
};
</script>

<style>
  #main-title{
    margin: 4% auto;
  }
  
</style>